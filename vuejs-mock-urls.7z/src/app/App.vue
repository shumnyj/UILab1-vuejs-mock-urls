<template>
  <div id="app">
    <h1>{{msg}}</h1>
  </div>
</template>

<script>
export default {
  data: function() {
    return {
      msg: "Hello"
    };
  }
};
</script>
