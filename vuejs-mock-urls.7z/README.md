# UILab1
User interfaces programming lab #1 <br/>
Виконав: Троян Борис КВ-02мп <br/>
Звіт:  https://docs.google.com/document/d/1MheeRjGPxwcIgZyWlnoiAHJNQ9sFS4jodY2h4u3dQUI/edit?usp=sharing <br/>
 
Загальне завдання: розробити клієнтську частину Web-додатку.<br/>
Інструменти розробки: VS Code, Javascript/VueJS, Twitter Bootstrap, NodeJS, diagram.net <br/>

Web-додаток має містити наступні сторінки: <br/>
- реєстрація користувача (поля: ім’я, email, стать, дата народження)  
- вхід до сайту (поля: email, пароль)  
- профіль користувача (поля у табличному вигляді)  
- про додаток (емблема додатку, короткий опис додатка)  
- робочі функції додатка (розробляється самостійно студентом відповідно до обраної тематики)  
